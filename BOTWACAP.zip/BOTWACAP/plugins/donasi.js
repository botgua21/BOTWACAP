let handler = async m => m.reply(`
╭─「 Donasi • Pulsa 」
│ • Indosat Ooredoo [085-784-771-854]
│ • Xl: [083-856-085-455]
│ 「 Chat OWNER 」
│ > Ingin donasi? Wa.me/6283856085455]
╰────
`.trim()) // Tambah sendiri kalo mau
handler.help = ['donasi']
handler.tags = ['about']
handler.command = /^dona(te|si)$/i

module.exports = handler
